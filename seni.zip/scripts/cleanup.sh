#!/bin/bash
rm -rf /home/ubuntu/build/*
