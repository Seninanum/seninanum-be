#!/bin/bash
REPOSITORY=/home/ubuntu/build
cd $REPOSITORY

npm install
npm start

